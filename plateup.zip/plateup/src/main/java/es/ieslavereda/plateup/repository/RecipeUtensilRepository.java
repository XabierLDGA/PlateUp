package es.ieslavereda.plateup.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import es.ieslavereda.plateup.model.RecipeUtensil;
import es.ieslavereda.plateup.model.RecipeUtensilId;

import java.util.Collection;

public interface RecipeUtensilRepository extends JpaRepository<RecipeUtensil, RecipeUtensilId> {
    void deleteByRecipe_idIn(Collection<Long> recipeIds);
}