package es.ieslavereda.plateup.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import es.ieslavereda.plateup.model.CollectionRecipe;
import es.ieslavereda.plateup.model.CollectionRecipeId;

import java.util.Collection;

public interface CollectionRecipeRepository extends JpaRepository<CollectionRecipe, CollectionRecipeId> {
    void deleteByCollection_idIn(Collection<Long> collectionIds);
    void deleteByRecipe_idIn(Collection<Long> recipeIds);
}